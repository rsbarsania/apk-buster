echo -e "\e[32m\n\n[+] Application Allows Backups\e[0m"
Io=$(find ./input/apk-decompile/ -type f -iname '*.xml' -exec grep -ia 'android:allowBackup="true"\|android:dataExtractionRules="true"\|android:allowBackup="false"\|android:dataExtractionRules="false"' {} +)

if [ -z "$Io" ]; then
    echo -e "\e[31m\n[-] Vulnerable: Application Allows Backups (No protection found)\e[0m"
elif echo "$Io" | grep -q 'android:allowBackup="true"'; then
    echo -e "\e[31m\n[-] Vulnerable: Application Allows Backups\e[0m"
elif echo "$Io" | grep -q 'android:dataExtractionRules="true"'; then
    echo -e "\e[31m\n[-] Vulnerable: Application Allows Data Extraction\e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
