#!/bin/bash

apt-get update
apt-get upgrade
apt-get keytool
