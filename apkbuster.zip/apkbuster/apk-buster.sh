#!/bin/bash


Banner(){
echo -e '\e[31m
  @@@@@@  @@@@@@@  @@@  @@@          @@@@@@@  @@@  @@@  @@@@@@ @@@@@@@ @@@@@@@@ @@@@@@@ 
 @@!  @@@ @@!  @@@ @@!  !@@          @@!  @@@ @@!  @@@ !@@       @@!   @@!      @@!  @@@
 @!@!@!@! @!@@!@!  @!@@!@!  @!@!@!@! @!@!@!@  @!@  !@!  !@@!!    @!!   @!!!:!   @!@!!@! 
 !!:  !!! !!:      !!: :!!           !!:  !!! !!:  !!!     !:!   !!:   !!:      !!: :!! 
  :   : :  :        :   :::          :: : ::   :.:: :  ::.: :     :    : :: :::  :   : :
                                                                                        
                                                                                                                                                                   
                                                                                                        
\e]0m'														   
echo -e "\e[33m\t\tBy Rishabh Singh \n\e[0m"
rm -rf ./logs/*
mkdir -p apk
mkdir -p input
mkdir -p ./logs
echo "apk" &> 1-Terminal.log
mv 1-Terminal.log ./logs/
}


Super(){



Ac=$(ls apk | wc -l)

if echo "$Ac" | grep '1' &> /dev/null ; then

    anm=$(ls ./apk/)
    echo -e "\e[33m\n[*] Provided APK file in apk folder is:\e[32m $anm\e[0m\n"
else 
    echo -e "\e[33m\n[-] Error: Provide only 1 APK file in apk folder.\e[0m"
    exit 1
fi

sleep 2
read -p "Press any key to continue......"

#echo -e "Provide your application's name:"
#read appName

#echo -e "You provided the application name: $appName"


ifile="./keywords.txt"



Decompile() {
echo -e "\e[32m\n[+] Decompiling the APK file\e[0m\n"

apktool d ./apk/"$anm" -o ./input/apk-decompile/ -f

Manifest="./input/apk-decompile/AndroidManifest.xml"
ayml="./input/apk-decompile/apktool.yml"
pan=$(cat ./input/apk-decompile/res/values/strings.xml | grep -oP '(?<=<string name="app_name">).*?(?=<\/string>)' | sed 's/&quot;/"/g')
xnma=$(cat ./input/apk-decompile/AndroidManifest.xml | grep -o 'package="[^"]*"' | sed 's/package="\([^"]*\)"/\1/')
}



MainApk() {
sd=$(sed 's/^[[:space:]]*//; s/[[:space:]]*$//; /^$/d' "$ifile" | sed 's/$/\\|/g' | sed '$s/\\|//' | tr -d '\n')
echo -e "\e[32m\n[+] Preparing keywords in the grep format (one\|two\|three): \e[0m"
echo "$sd"

if echo "$sd" | grep -E '\\\|$' &> /dev/null 
then echo "[-] Remove empty lines from keywords.txt file" 
fi

if echo "$sd" | grep -E '\\\|\\\|' &> /dev/null 
then echo "[-] Remove empty lines from keywords.txt file" 
fi

sdd=$(sed 's/^[[:space:]]*//; s/[[:space:]]*$//; /^$/d' "$ifile" | sed 's/$/\\|/g' | sed '$s/\\|//' | tr -d '\n' | sed 's/\\|/...\\|../g')
#echo "$sdd"
}




sensitive_data() {
echo -e "\e[32m\n\n[+] Deeply Scanning For Sensitive Data On All The Files Recursively\e[0m"
cat ./input/*.log > ./input/realtime.tmp
iconv -f UTF-16 -t UTF-8 < ./input/realtime.tmp > ./input/newrealtime.log


    find ./input/apk-decompile/ -type f -exec grep -iao "$sd\|..${sdd}...\|....secret.............\|latitude=...........\|longitude=...........\|access.key...........\|access.token...........\|admin.pass...........\|admin.user...........\|algolia.admin.key...........\|algolia.api.key...........\|alias.pass...........\|alicloud.access.key...........\|amazon.secret.access.key...........\|amazonaws...........\|ansible.vault.password...........\|aos.key...........\|api.key...........\|api.key.secret...........\|api.key.sid...........\|api.secret...........\|AIza...........\|apidocs...........\|apikey...........\|apiSecret...........\|app.debug...........\|app.id...........\|app.key...........\|app.log.level...........\|app.secret...........\|appkey...........\|appkeysecret...........\|application.key...........\|appsecret...........\|appspot...........\|auth.token...........\|authorizationToken...........\|authsecret...........\|aws.access...........\|aws.access.key.id...........\|aws.bucket...........\|aws.key...........\|aws.secret...........\|aws.secret.key...........\|aws.token...........\|AWSSecretKey...........\|b2.app.key...........\|bashrc.password...........\|bintray.apikey...........\|bintray.gpg.password...........\|bintray.key...........\|bintraykey...........\|bluemix.api.key...........\|bluemix.pass...........\|browserstack.access.key...........\|bucket.password...........\|bucketeer.aws.access.key.id...........\|bucketeer.aws.secret.access.key...........\|built.branch.deploy.key...........\|bx.password...........\|cache.driver...........\|cache.s3.secret.key...........\|cattle.access.key...........\|cattle.secret.key...........\|certificate.password...........\|ci.deploy.password...........\|client.secret...........\|client.zpk.secret.key...........\|clojars.password...........\|cloud.api.key...........\|cloud.watch.aws.access.key...........\|cloudant.password...........\|cloudflare.api.key...........\|cloudflare.auth.key...........\|cloudinary.api.secret...........\|cloudinary.name...........\|codecov.token...........\|conn.login...........\|connectionstring...........\|consumer.key...........\|consumer.secret...........\|cypress.record.key...........\|database.password...........\|database.schema.test...........\|datadog.api.key...........\|datadog.app.key...........\|db.password...........\|db.server...........\|db.username...........\|dbpasswd...........\|dbpassword...........\|dbuser...........\|deploy.password...........\|digitalocean.ssh.key.body...........\|digitalocean.ssh.key.ids...........\|docker.hub.password...........\|docker.key...........\|docker.pass...........\|docker.passwd...........\|docker.password...........\|dockerhub.password...........\|dockerhubpassword...........\|dot.files...........\|dotfiles...........\|droplet.travis.password...........\|dynamoaccesskeyid...........\|dynamosecretaccesskey...........\|elastica.host...........\|elastica.port...........\|elasticsearch.password...........\|encryption.key...........\|encryption.password...........\|env.heroku.api.key...........\|env.sonatype.password...........\|eureka.awssecretkey..........." {} + | sed 's/:/ ==>    /' | tee ./logs/CS-Sens-Data.tmp

    find ./input/apk-decompile/ -type f -exec grep -HanoE '.......(eyJ)[%a-zA-Z0-9+/]+={0,2}.(eyJ)[%a-zA-Z0-9+/]+={0,2}' {} + | sort -u | cut -b 1-250 | sed 's/:/ ==>    /' | tee -a ./logs/CS-Sens-Data.tmp

    cat ./logs/CS-Sens-Data.tmp | sort -u > ./logs/CS-Sensitive-Data.txt

    find "./input/" -not -path "*/apk-decompile/*" -type f -exec grep -iao "$sd\|..${sdd}...\|....secret.............\|latitude=...........\|longitude=...........\|access.key...........\|access.token...........\|admin.pass...........\|admin.user...........\|algolia.admin.key...........\|algolia.api.key...........\|alias.pass...........\|alicloud.access.key...........\|amazon.secret.access.key...........\|amazonaws...........\|ansible.vault.password...........\|aos.key...........\|api.key...........\|api.key.secret...........\|api.key.sid...........\|api.secret...........\|AIza...........\|apidocs...........\|apikey...........\|apiSecret...........\|app.debug...........\|app.id...........\|app.key...........\|app.log.level...........\|app.secret...........\|appkey...........\|appkeysecret...........\|application.key...........\|appsecret...........\|appspot...........\|auth.token...........\|authorizationToken...........\|authsecret...........\|aws.access...........\|aws.access.key.id...........\|aws.bucket...........\|aws.key...........\|aws.secret...........\|aws.secret.key...........\|aws.token...........\|AWSSecretKey...........\|b2.app.key...........\|bashrc.password...........\|bintray.apikey...........\|bintray.gpg.password...........\|bintray.key...........\|bintraykey...........\|bluemix.api.key...........\|bluemix.pass...........\|browserstack.access.key...........\|bucket.password...........\|bucketeer.aws.access.key.id...........\|bucketeer.aws.secret.access.key...........\|built.branch.deploy.key...........\|bx.password...........\|cache.driver...........\|cache.s3.secret.key...........\|cattle.access.key...........\|cattle.secret.key...........\|certificate.password...........\|ci.deploy.password...........\|client.secret...........\|client.zpk.secret.key...........\|clojars.password...........\|cloud.api.key...........\|cloud.watch.aws.access.key...........\|cloudant.password...........\|cloudflare.api.key...........\|cloudflare.auth.key...........\|cloudinary.api.secret...........\|cloudinary.name...........\|codecov.token...........\|conn.login...........\|connectionstring...........\|consumer.key...........\|consumer.secret...........\|cypress.record.key...........\|database.password...........\|database.schema.test...........\|datadog.api.key...........\|datadog.app.key...........\|db.password...........\|db.server...........\|db.username...........\|dbpasswd...........\|dbpassword...........\|dbuser...........\|deploy.password...........\|digitalocean.ssh.key.body...........\|digitalocean.ssh.key.ids...........\|docker.hub.password...........\|docker.key...........\|docker.pass...........\|docker.passwd...........\|docker.password...........\|dockerhub.password...........\|dockerhubpassword...........\|dot.files...........\|dotfiles...........\|droplet.travis.password...........\|dynamoaccesskeyid...........\|dynamosecretaccesskey...........\|elastica.host...........\|elastica.port...........\|elasticsearch.password...........\|encryption.key...........\|encryption.password...........\|env.heroku.api.key...........\|env.sonatype.password...........\|eureka.awssecretkey.........." {} + | sed 's/:/ ==>    /' | tee ./logs/Sensitive-Data.tmp

    find ./input/ -not -path "*/apk-decompile/*" -type f -exec grep -HanoE '.......(eyJ)[%a-zA-Z0-9+/]+={0,2}.(eyJ)[%a-zA-Z0-9+/]+={0,2}' {} + | sort -u | cut -b 1-250 | sed 's/:/ ==>    /' | tee -a ./logs/Sensitive-Data.tmp

    cat ./logs/Sensitive-Data.tmp | sort -u > ./logs/Sensitive-Data.txt
}



Mnnl(){


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Unmasked NPI / PHI / PII Data [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
   	echo -e "\e[31m\n[-] Vulnerable: Unmasked Data\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Application Allows Sensitive Data to be Copied [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
   	echo -e "\e[31m\n[-] Vulnerable: Application Allows Sensitive Data to be Copied\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Application Screenshot Information Disclosure [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Application Screenshot Information Disclosure\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Application not Disabling Custom Keyboards [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Application not Disabling Custom Keyboards\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Authentication Bypass via Enrolling Additional Biometrics [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Authentication Bypass via Enrolling Additional Biometrics\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done

while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Weak Implementation of Biometric Authentication [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Weak Implementation of Biometric Authentication\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done

while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] No Root Detection [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: No Root Detection\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done

while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Root Detection Bypass [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Root Detection Bypass\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Lack of Certificate Pinning [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Lack of Certificate Pinning\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done

while true; do
  read -rp "$(echo -e "\e[32m\n\n[+] Certificate Pinning Bypass [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: Certificate Pinning Bypass\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done



#echo -e "\e[31m\n[#] Please execute the windows CMD script before proceeding\e[0m"



while true; do
  read -rp "$(echo -e "\e[33m\n\n[*] No Authentication After Background Resume? [y/n]: \e[0m")" -e answer
  echo

  if [[ $answer =~ ^[Yy]$ ]]; then
	echo -e "\e[31m\n[-] Vulnerable: No Authentication After Background Resume\e[0m"
    break
  elif [[ $answer =~ ^[Nn]$ ]]; then
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    break
  else
    echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
  fi
done


}





Mos() {
    iinfo="./input/apk-decompile/apktool.yml"

    echo -e "\e[32m\n\n[+] Vulnerable Minimum OS Version Supported\e[0m"
    echo -e "\n~ root#\e[93m cat apktool.yml | grep -i -A1 'minSdkVersion'\e[0m"

    cat "$iinfo" | grep -i -A1 -B1 'minSdkVersion'

    Io=$(cat "$iinfo" | grep -i -A1 'minSdkVersion' | awk -F"'" '/minSdkVersion/ {print $2}')
    echo "$Io"

    if [ "$Io" -ge 30 ]; then
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    else
        echo -e "\e[31m\n[-] Vulnerable: Vulnerable Minimum OS Version Supported\e[0m"
    fi
}




DebFlag() {
      
    echo -e "\e[32m\n\n[+] Debuggable Flag Set to True in Application Manifest\e[0m"
    echo -e "\n~ root#\e[93m cat AndroidManifest.xml | grep -i -A1 'android:debuggable'\e[0m"

    Io=$(cat "$Manifest" | grep -i 'android:debuggable="true"' | awk -F'"' '{print $2}')
    echo "$Io"

    if [ "$Io" = "true" ]; then
        echo -e "\e[31m\n[-] Vulnerable: Debuggable Flag Set to True in Application Manifest\e[0m"
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}






AppReqPerm() {

echo -e "\e[32m\n\n[+] Application Requests Permissions That It May Not Need\e[0m"
#echo -e "\n~ root#\e[93m cat AndroidManifest.xml | grep -iao 'android.permission.CALL_PHONE\|android.permission.SEND_SMS\|android.permission.READ_SMS\|android.permission.INSTALL_PACKAGES\|android.permission.READ_PHONE_STATE\|android.permission.WRITE_CALENDAR\|android.permission.WRITE_EXTERNAL_STORAGE\|android.permission.DELETE_PACKAGES'"
Io=$(cat "$Manifest" | grep -ia 'android.permission.CALL_PHONE\|android.permission.SEND_SMS\|android.permission.READ_SMS\|android.permission.INSTALL_PACKAGES\|android.permission.READ_PHONE_STATE\|android.permission.WRITE_CALENDAR\|android.permission.WRITE_EXTERNAL_STORAGE\|android.permission.DELETE_PACKAGES')

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application Requests Permissions That It May Not Need\e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}





AppReqDang() {
echo -e "\e[32m\n\n[+] Application Requests Dangerous or Suspicious Permissions\e[0m"
Io=$(cat "$Manifest" | grep -ia 'android.permission.CALL.PHONE\|android.permission.CALL.PRIVILEGED\|android.permission.SEND.SMS\|android.permission.SEND.SMS.NO.CONFIRMATION\|android.permission.READ_SMS\|android.permission.RECEIVE_SMS\|android.permission.READ.INPUT.STATE\|android.permission.FILTER_EVENTS\|android.permission.INJECT_EVENTS\|android.permission.FACTORY_TEST\|android.permission.SET.ACTIVITY.WATCHER\|android.permission.CAPTURE.AUDIO.OUTPUT\|android.permission.CAPTURE.SECURE.VIDEO.OUTPUT\|android.permission.CAPTURE.VIDEO_OUTPUT\|android.permission.CLEAR.APP.USER_DATA\|android.permission.DELETE_PACKAGES\|android.permission.INSTALL_PACKAGES\|android.permission.WRITE.SECURE.SETTINGS\|android.permission.MASTER_CLEAR\|android.permission.FORCE_BACK\|android.permission.DUMP\|android.permission.ACCESS_SUPERUSER\|android.permission.DIAGNOSTIC\|android.permission.BROADCAST_SMS\|android.permission.CHANGE.COMPONENT.ENABLED_STATE\|android.permission.BROADCAST\|android.permission.SYSTEM\|android.permission.BRICK\|android.permission.CONTROL.LOCATION.UPDATES\|android.permission.GET.TOP.ACTIVITY_INFO')

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application Requests Dangerous or Suspicious Permissions\e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}






ClrTxt1() {
    echo -e "\e[32m\n\n[+] Cleartext HTTP Traffic is Permitted\e[0m"
    iinfo="./input/apk-decompile/apktool.yml"
    manifest="./input/apk-decompile/AndroidManifest.xml"

    cat "$iinfo" | grep -i -A1 -B1 'minSdkVersion'

    minSdkVersion=$(cat "$iinfo" | grep -i -A1 'minSdkVersion' | awk -F"'" '/minSdkVersion/ {print $2}')
    echo "Minimum SDK Version: $minSdkVersion"

    if [ "$minSdkVersion" -lt 28 ]; then
        # If minSdkVersion is less than 28, check if "android:usesCleartextTraffic" is explicitly set to "FALSE"
        if grep -q 'android:usesCleartextTraffic="false"' "$manifest"; then
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
        else
            echo -e "\e[31m\n[-] Vulnerable: Minimum SDK Version is less than 28, but Cleartext HTTP Traffic is not explicitly set to 'FALSE'\e[0m"
        fi
    elif [ "$minSdkVersion" -ge 28 ]; then
        # If minSdkVersion is 28 or greater, check if "android:usesCleartextTraffic" is explicitly set to "TRUE"
        if grep -q 'android:usesCleartextTraffic="true"' "$manifest"; then
            echo -e "\e[31m\n[-] Vulnerable: Minimum SDK Version is 28 or greater, and Cleartext HTTP Traffic is explicitly set to 'TRUE'\e[0m"
        else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
        fi
    fi
}








AppBackup() {
    
    echo -e "\e[32m\n\n[+] Application Allows Backups\e[0m"
    Io=$(find ./input/apk-decompile/ -type f -iname '*.xml' -exec grep -ia 'android:allowBackup="true"\|android:dataExtractionRules="true"\|android:allowBackup="false"\|android:dataExtractionRules="false"' {} +)

    if [ -z "$Io" ]; then
        echo -e "\e[31m\n[-] Vulnerable: Application Allows Backups (No protection found)\e[0m"
    elif echo "$Io" | grep -q 'android:allowBackup="true"'; then
        echo -e "\e[31m\n[-] Vulnerable: Application Allows Backups\e[0m"
    elif echo "$Io" | grep -q 'android:dataExtractionRules="true"'; then
        echo -e "\e[31m\n[-] Vulnerable: Application Allows Data Extraction\e[0m"
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}





Cao(){
echo -e "\e[32m\n\n[+] PhoneGap or Cordova Access Origin is Set Too Broadly\e[0m"
Io=$(find ./input/apk-decompile/ -type f -iname *.xml -exec grep -ia '<access origin="\*"' {} + | sed 's/:/ ==>  /' | sort -u)
echo "$Io"

if echo "$Io" | grep -i 'access origin' &> /dev/null ; then
	echo -e  "\e[31m\n[-] Vulnerable: PhoneGap or Cordova Access Origin is Set Too Broadly\e[0m"
else
	echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}






AppAddJava() {
echo -e "\e[32m\n\n[+] Application Uses addJavaScriptInterface Method\e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'addJavaScriptInterface(.....' {} + | sed 's/:/ ==>  /' | sort -u)
echo "$Io"

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application Uses addJavaScriptInterface Method\e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}






Irn() {
echo -e "\e[32m\n\n[+] Insecure random number generator in use\e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'math\.random....\|java\.util\.Random\|arc4random' {} + | sed 's/:/ ==>  /' | sort -u)

echo "$Io" | head -10
echo "$Io" > ./logs/Insecure-Pseudo-Random-Number-Generator-Used.txt

#Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'math.random\|java.util.Random\|arc4random\|rand(' {} + | head -n 10)

if [ -n "$Io" ]; then
    #echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Insecure random number generator in use\e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}






Ipp(){
echo -e "\e[32m\n\n[+] Internal IP Disclosure\e[0m"

echo -e "\e[33m\n[*] Searching for IPv4:\e[0m"
Io=$(find "./input/apk-decompile/" -type f -exec grep -a -o '..[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}...' {} + | sort -u | sed 's/:/ ==>  /' | grep -ia -v '\.png\|\.ttf\|\.jpeg\|\.jpg\|\.log\|strings\.txt\|dump\.data\|memorydump\|>  0\|\.0\|>  1\.\|>  2\.\|>  3\.') 

# grep -Ea '\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b')

#echo "$Io" | head -30


if echo "$Io" | grep -va '127.0.0.1\|10...\.' | grep -ia ' ..10\.\| ..172\.\| ..192\.\| ..127\.\| ..169\.254\.' ; then
	echo -e  "\e[31m\n[*] Possible: Internal IP Disclosure\e[0m"
else
  echo "$Io" | grep -iva ' 10\.\| 172\.\| 192\.\| 127\.\| 169\.254\.\|127.0.0.1\|>  0\|\.0\|>  1\.\|>  2\.\|>  3\.\|>  4\.\|>  5\.\|>  6\.\|>  7\.\|\.svg\|blob' | head -30
	echo -e "\e[33m\n[*] Info: Internal IP Disclosure (Check the "6-Internal-IP-Disclosure-IPv4.txt" log file)\e[0m"
fi

echo -e "\e[33m\n[*] Searching for IPv6:\e[0m"
Io=$(find "./input/apk-decompile/" -type f -exec grep -iao '(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))' {} + | sort -u | sed 's/:/ ==>        /')
echo "$Io" | head -30

#echo -e  "\e[31m\n[*] Possible: Internal IP Disclosure\e[0m"
}




HcodedS(){
echo -e "\e[32m\n\n[+] Exposed Secrets in Client-side Code\e[0m"


#find "$nf"/ -type f -exec grep -iao "$sd\|latitude=...........\|longitude=......" {} + | sed 's/:/ ==>    /' > ./logs/CS-Sensitive-Data.txt

#cat ./logs/CS-Sensitive-Data.txt | sort -u | head -30

#find "$nf"/ -type f -exec grep -HanoE '.......(eyJ)[%a-zA-Z0-9+/]+={0,2}.(eyJ)[%a-zA-Z0-9+/]+={0,2}' {} + | sort -u | cut -b 1-250 | sed 's/:/ ==>    /' >> ./logs/CS-Sensitive-Data.txt



if cat ./logs/CS-Sensitive-Data.txt | grep -ia "$sd" &> /dev/null ; then
  cat ./logs/CS-Sensitive-Data.txt | grep -ia "$sd" | head -30
	echo -e  "\e[31m\n[-] Vulnerable: Exposed Secrets in Client-side Code\e[0m"
else
	echo -e "\e[33m\n[*] Info: Exposed Secrets in Client-side Code (Not found any word from keywords.txt data, Check the "CS-Sensitive-Data.txt" log file)\e[0m"
fi

}









Senssyslogs() {
  echo -e "\e[32m\n[+] Sensitive Data Logged to System logs\e[0m"
  
  Io=$(cat ./logs/Sensitive-Data.txt | grep -ia "\.log\|realtime")
  #Oo=$(iconv -f UTF-16 -t UTF-8 < ./output/directpay/zinput/realtime.log )

  # Save both Io and Oo to the same file (append mode)
  echo "$Io" > ./logs/Sensitive-Data-Logged-to-System-logs.txt
  #echo "$Oo" >> ./logs/Sensitive-Data-Logged-to-System-logs.txt

  echo "$Io" | head -30
    
  if echo "$Io" | grep -ia "$sd" &> /dev/null ; then
    echo -e  "\e[31m\n[-] Vulnerable: Sensitive Data Logged to System logs\e[0m"
  else
    echo -e "\n[#] Not Vulnerable (Not found any word from keywords.txt data)\n"
  fi

}





SensWc(){

echo -e "\e[32m\n[+] Sensitive Data in WebView Cache\e[0m"
Io=$(cat ./logs/Sensitive-Data.txt | grep -ia "\/cache\/") 

echo "$Io" > ./logs/Sensitive-Data-in-WebView-Cache.txt

echo "$Io" | head -30
if echo "$Io" | grep -ia "$sd" &> /dev/null ; then
	echo -e  "\e[31m\n[-] Vulnerable: Sensitive Data in WebView Cache\e[0m"
  else
	echo -e "\n[#] Not Vulnerable (Not found any word from keywords.txt data)\n"
fi
}





SensLs() {
echo -e "\e[32m\n[+] Sensitive Data Stored Unencrypted in Local Storage\e[0m"
#Io=$(cat ./logs/Sensitive-Data.txt | grep -ia "metadata\|manifest\|\.settings\|\.sql\|\.db\|\.localstorage")
Io=$(cat ./logs/Sensitive-Data.txt | grep -iav "memory\|dump\|strings.txt\|\.log\|realtime\|\/cache\/")

echo "$Io" > ./logs/Sensitive-Data-Stored-Unencrypted-in-Local-Storage.txt

echo "$Io" | head -30

if echo "$Io" | grep -ia "$sd" &> /dev/null ; then
	echo -e  "\e[31m\n[-] Vulnerable: Sensitive Data Stored Unencrypted in Local Storage\e[0m"
  else
	echo -e "\n[#] Not Vulnerable (Not found any word from keywords.txt data)\n"
fi
}






CredinMem() {

echo -e "\e[32m\n[+] Credential Kept in Memory After Login\e[0m"
Io=$(cat ./logs/Sensitive-Data.txt | grep -ia "memory\|dump\|strings.txt")

echo "$Io" > ./logs/Credential-Kept-in-Memory-After-Login.txt

echo "$Io" | grep -ia "$sd"
echo "$Io" | head -30

if echo "$Io" | grep -ia "$sd" &> /dev/null ; then
  echo -e "\n"
	while true; do
  echo -e "\e[33m"
  read -rp "Based on the above output, please verify the presence of both username and password. [y/n]: " -n 1 -e answer
  echo -e "\e[0m"
  
    if [[ $answer =~ ^[Yy]$ ]]; then
	  echo -e  "\e[31m\n[-] Vulnerable: Credential Kept in Memory After Login\e[0m"
      break
    elif [[ $answer =~ ^[Nn]$ ]]; then
	  echo -e "\e[33m\n[*] Additional Observation: Credential Kept in Memory After Login\e[0m"
      break
    else
      echo -e "Invalid input. Please enter 'y' for yes or 'n' for no.\n"
    fi
  done
  else
	  echo -e "\n[#] Not Vulnerable (Not found any word from keywords.txt data)\n"
fi
}





SensDinKey() {

echo -e "\e[32m\n\n[+] Sensitive Data Getting Stored In Keyboard Cache\e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'textNoSuggestions' {} + | sed 's/:/ ==>  /' | sort -u)
echo "$Io"

if [ -n "$Io" ]; then
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
else
    echo -e "\e[31m\n[-] Vulnerable: Application stores sensitive Data in Keyboard Cache\e[0m"
fi
}






TapJack(){
echo -e "\e[32m\n\n[+] Application Does Not Prevent Tapjacking\e[0m"
echo -e "\e[33m[*] Searching for: onFilterTouchEventForSecurity and filterTouchesWhenObscured \e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'onFilterTouchEventForSecurity\|filterTouchesWhenObscured' {} + | sed 's/:/ ==>  /' | sort -u)
echo "$Io"

if [ -n "$Io" ]; then
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
else
    echo -e "\e[31m\n[-] Vulnerable: Application Does Not Prevent Tapjacking\e[0m"
fi
}





LoadUrl(){
echo -e "\e[32m\n\n[+] loadUrl() Using String Concatenation in WebView\e[0m"
#Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'webview.loadUrl............' {} +)
#Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'webview.loadUrl.*' {} +)

Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa '.\.loadUrl...' {} + | sed 's/:/ ==>  /' | sort -u)

echo "$Io"

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application uses loadUrl() Using String Concatenation in WebView \e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}



Aeswcbc(){
echo -e "\e[32m\n\n[+] AES Used with CBC Cipher Mode\e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'Cipher.getInstance("AES/CBC/PKCS5Padding").*' {} + | sed 's/:/ ==>  /' | sort -u)

echo "$Io"

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application uses AES with CBC Cipher Mode \e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}





Rsawpad(){
echo -e "\e[32m\n\n[+] RSA Used with No Padding\e[0m"
Io=$(find ./input/apk-decompile/ -type f -exec grep -ioa 'Cipher.getInstance("RSA/ECB/NoPadding").*' {} + | tr -d '\0')

echo "$Io"

if [ -n "$Io" ]; then
    echo -e "$Io"
    echo -e "\e[31m\n[-] Vulnerable: Application uses RSA with No Padding \e[0m"
else
    echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
fi
}





Appjanus(){
    echo -e "\e[32m\n\n[+] Application is vulnerable to Janus \e[0m"
    Io=$(./tools/build-tools/34.0.0/apksigner verify -v ./apk/"$anm")
    Oo=$(echo "$Io" | grep -ai "using v1" | head -1)
    echo "$Io" | head -10
    

    if echo "$Oo" | grep -ia "true" ; then
        echo -e "$Oo"
        echo -e "\e[31m\n[-] Vulnerable: Application is vulnerable to Janus\e[0m"
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}




AppsignDebug(){
 echo -e "\e[32m\n\n[+] Application Signed Using Debug Certificate\e[0m"
    Io=$(./tools/build-tools/34.0.0/apksigner verify --print-certs ./apk/"$anm" | grep -iA1 "debug")

    if [ -n "$Io" ]; then
        echo "$Io"
        keybit=$(echo "$Io" | sed -n 's/.*CN=\([^,]*\).*/\1/p' | grep "Debug")
        if [ "$keybit" = "debug" ]; then
            echo -e "\e[31m\n[-] Vulnerable: Application is Signed Using Debug Certificate\e[0m"
        else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
        fi
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}


getKeytoolOutputm1() {

    echo -e "\e[32m\n\n[+] M1: Certificate related findings\e[0m"
    echo -e "\n~ root#\e[93m ./tools/java-17-openjdk-amd64/bin/keytool -printcert -jarfile ./apk/$anm\e[0m"
    Cm=$(keytool -printcert -jarfile "./apk/$anm")
    echo "$Cm"
}

#add m1 keytool.exe -printcert -jarfile "app-release.apk"
#add m2 with rsa file 
getKeytoolOutputm2() {
    echo -e "\e[32m\n\n[+] M2: Certificate related findings\e[0m"
    echo -e "\n~ root#\e[93m ./tools/java-17-openjdk-amd64/bin/keytool -printcert -file ./input/apk-decompile/original/META-INF/CERT.RSA\e[0m"
    echo -e "$(keytool -printcert -file "./input/apk-decompile/original/META-INF/CERT.RSA" | tee ./logs/certm2.txt)"
}



X509Certsign() {
    echo -e "\e[32m\n\n[+] X.509 Certificate Signature Hashing Algorithm\e[0m"

    if echo "$Cm" | grep -iao "SHA1withRSA" &> /dev/null ; then
     
     echo -e "\e[31m\n[-] Vulnerable: Application uses X.509 Certificate Signature Hashing Algorithm SHA1withRSA\e[0m"
    else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi

    
            
    Io=$(getKeytoolOutputm2 | grep "Signature algorithm name:")

    if [ -n "$Io" ]; then
        echo "$Io"  # Print the line containing "Signature algorithm name:"
        algorithm=$(echo "$Io" | sed -n 's/.*: \(.*\)/\1/p')  # Extract the algorithm part
        if [ "$algorithm" = "SHA1withRSA" ]; then
            echo -e "\e[31m\n[-] Vulnerable: Application uses X.509 Certificate Signature Hashing Algorithm SHA1withRSA\e[0m"
        else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
        fi
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}




Apkkeys() {
    echo -e "\e[32m\n\n[+] APK Signature Contains RSA Keys Less Than 2048 Bits\e[0m"
    
    if echo "$Cm" | grep -iao "1024.bit" &> /dev/null ; then
         echo -e "\e[31m\n[-] Vulnerable: APK Signature Contains RSA Keys Less Than 2048 Bits\e[0m"
    else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi 
    
    
    
    Io=$(getKeytoolOutputm2 | grep "Subject Public Key Algorithm:")

    if [ -n "$Io" ]; then
        echo "$Io"
        keybit=$(echo "$Io" | sed -n 's/.*: \(.*\)/\1/p')
        if [ "$keybit" = "1024-bit RSA key" ]; then
            echo -e "\e[31m\n[-] Vulnerable: APK Signature Contains RSA Keys Less Than 2048 Bits\e[0m"
        else
            echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
        fi
    else
        echo -e "\e[33m\n[#] Not Vulnerable\e[0m"
    fi
}


Str_gen(){

  

cat ./logs/1-Terminal.log | sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2};?)?)?[mGK]//g" | grep -a 'Vulnerable:\|Possible:\|Observation:' | sed 's/\[-] Vulnerable://g' | sed 's/\[\*] Possible://g' | sed 's/\[\*] Additional Observation://g' | sed 's/ //' | awk -F', ' '!a[$1 FS $2]++' > ./logs/2-sof.log

#echo -e "Application Binary File Name (ps aux | grep -i "$nb"): \t<----app-bin-name---->\nApplication Name (frida-ps -Ua): \t\t\t<----app-name---->\nApplication Identifier Name (frida-ps -Ua): \t\t<----app-pkg-name---->\nJbDisabled-SSLDisabled: \t\t\t\t<----fileJD-SD.ipa---->\nJbDisabled-SSLEnabled: \t\t\t\t\t<----fileJD-SE.ipa---->\nJbEnabled-SSLEnabled: \t\t\t\t\t<----fileJDE-SE.ipa---->\n==================================================================================\n\n" > ./"${adn}"/logs/3-STR.txt

echo -e "Application Binary File Name (ps aux | grep -i "$anm"): \t"$nb"\nApplication Name (frida-ps -Ua): \t\t\t"$pan"\nApplication Identifier Name (frida-ps -Ua): \t\t"$xnma"\nIPA-File: \t\t\t\t<----IPA-File---->.ipa\nSSL-Enabled-IPA: \t\t\t\t\t<----SSL---->.ipa\nJB-Enabled-IPA: \t\t\t\t\t<----JB---->.ipa\n==================================================================================\n\n" > ./logs/3-STR.txt


file=./mainSTRs.txt
i=1

while IFS= read vn;
do 
echo "$i. $(awk "/${vn}/{p=1} p && /=============/ {exit} p" "$file")"
((i=i+1))
echo -e "\n"
done < ./logs/2-sof.log >> ./logs/3-STR.txt

echo

sed -i "s/<--mos-->/$mos.0/g" ./logs/3-STR.txt
sed -i "s/<----app-bin-name---->/$nb/g" ./logs/3-STR.txt
sed -i "s/<----app-name---->/$pan/g" ./logs/3-STR.txt
sed -i "s/<----app-pkg-name---->/$xnma/g" ./logs/3-STR.txt
Tnf=$(echo $nf | sed 's/\//\\\//g')
sed -i "s/<--bfp-->/$Tnf/g" ./logs/3-STR.txt
Txnmb=$(echo $xnmb | sed 's/\//\\\//g')
sed -i "s/<--dfp-->/$Txnmb/g" ./logs/3-STR.txt
Txsp=$(echo $xsp | sed 's/\//\\\//g')
sed -i "s/<--xssp-->/$Txsp/g" ./logs/3-STR.txt
Txsl=$(echo $xsl | sed 's/\//\\\//g')
sed -i "s/<--xssl-->/$Txsl/g" ./logs/3-STR.txt

echo -e "\e[33m[/] Creating a logs-${anm}.zip file containing all the logs generated during the current run of the tool.\e[0m"
zip -r ./"${adn}"/logs-${anm}.zip ./"${adn}"/logs/ &> /dev/null
}


Decompile
MainApk
sensitive_data #
Mnnl
Mos # Vulnerable Minimum OS Version Supported
DebFlag # Debuggable Flag Set to True in Application Manifest
AppReqPerm # Application Requests Permissions That It May Not Need
AppReqDang # Application Requests Dangerous or Suspicious Permissions
ClrTxt1 # Cleartext HTTP Traffic is Permitted
AppBackup # Application Allows Backups
Cao # PhoneGap or Cordova Access Origin is Set Too Broadly
AppAddJava # Application Uses addJavaScriptInterface Method
Irn # Insecure random number generator in use
Ipp # Internal IP Disclosure
HcodedS # Exposed Secrets in Client-side Code
Senssyslogs # Sensitive Data Logged to System logs
SensWc # Sensitive Data in WebView Cache
SensLs # Sensitive Data Stored Unencrypted in Local Storage
CredinMem # Credential Kept in Memory After Login
SensDinKey # Sensitive Data Getting Stored In Keyboard Cache
TapJack # Application Does Not Prevent Tapjacking
LoadUrl # loadUrl() Using String Concatenation in WebView
Aeswcbc # AES Used with CBC Cipher Mode
Rsawpad # RSA Used with No Padding
Appjanus # Application is vulnerable to Janus
AppsignDebug # Application Signed Using Debug Certificate
getKeytoolOutputm1 # keytool output
getKeytoolOutputm2
X509Certsign # X.509 Certificate Signature Hashing Algorithm
Apkkeys # APK Signature Contains RSA Keys Less Than 2048 Bits
Str_gen

echo -e "\e[32m\n\n[+] Summary Of Findings:\e[0m\n"  
cat "./logs/1-Terminal.log" | grep -a 'Vulnerable:' | sort -u
cat "./logs/1-Terminal.log" | grep -a 'Possible:'
cat "./logs/1-Terminal.log" | grep -a 'Additional Observation:'
cat "./logs/1-Terminal.log" | grep -a ' Info:'

}

Banner 
Super | tee ./logs/1-Terminal.log
